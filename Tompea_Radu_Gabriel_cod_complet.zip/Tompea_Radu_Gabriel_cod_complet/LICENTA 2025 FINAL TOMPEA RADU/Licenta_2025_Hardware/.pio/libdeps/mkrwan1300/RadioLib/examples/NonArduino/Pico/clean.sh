#!/bin/bash

rm -rf ./build
